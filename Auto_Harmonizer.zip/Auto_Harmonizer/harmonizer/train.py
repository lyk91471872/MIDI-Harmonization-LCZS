#!/usr/bin/env python3
# harmonizer/train.py

import os
import glob
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, ConcatDataset
from tqdm import tqdm

# -----------------------------
# 超参数设置
EMBED_DIM    = 128    # embedding 维度
LSTM_HIDDEN  = 256    # LSTM 隐藏尺寸
NUM_VOICES   = 3      # 生成声部数：Alto, Tenor, Bass
VOCAB_SIZE   = 128    # MIDI 音高 0–127
DUR_VOCAB    = 128    # 最大持续格点数
BATCH_SIZE   = 16
EPOCHS       = 20
LR           = 1e-3
# -----------------------------

def infer_durations(melody_row):
    """
    从单声部网格化序列推断每个格点的持续时长（以格点数计）。
    melody_row: 1D numpy array, 每个元素是 0 或 MIDI pitch
    """
    T = len(melody_row)
    dur = np.zeros(T, dtype=np.int64)
    i = 0
    while i < T:
        p = melody_row[i]
        if p == 0:
            dur[i] = 1
            i += 1
        else:
            j = i + 1
            while j < T and melody_row[j] == p:
                j += 1
            run = j - i
            dur[i] = run
            i = j
    # 将中间填充的 0 置为 1
    dur[dur == 0] = 1
    return dur

def find_npz_splits(data_dir):
    """
    自动发现 data_dir/*.npz 并按文件名划分 train/valid/test。
    """
    files = glob.glob(os.path.join(data_dir, '*.npz'))
    train = [p for p in files if 'valid' not in p.lower() and 'test' not in p.lower()]
    valid = [p for p in files if 'valid' in p.lower()]
    test  = [p for p in files if 'test'  in p.lower()]
    return train, valid, test

class HarmonyDataset(Dataset):
    """
    从 .npz 中加载 melody, (可选) melody_dur, alto, tenor, bass。
    若 npz 中无 melody_dur 则自动推断。
    """
    def __init__(self, npz_path):
        data = np.load(npz_path)
        melody = data['melody']      # shape (N, T)
        self.alto  = torch.from_numpy(data['alto']).long()
        self.tenor = torch.from_numpy(data['tenor']).long()
        self.bass  = torch.from_numpy(data['bass']).long()

        if 'melody_dur' in data.files:
            dur = data['melody_dur']
        else:
            # 推断 durations
            dur = np.stack([infer_durations(row) for row in melody], axis=0)
        # 转 torch
        self.melody = torch.from_numpy(melody).long()
        self.dur    = torch.from_numpy(dur).long()

    def __len__(self):
        return self.melody.size(0)

    def __getitem__(self, idx):
        return (
            self.melody[idx],  # (T,)
            self.dur[idx],     # (T,)
            self.alto[idx],
            self.tenor[idx],
            self.bass[idx]
        )

def pad_collate(batch):
    """
    在 batch 内对各序列动态 pad 到相同长度。
    batch: list of tuples (mel, dur, alto, tenor, bass)
    """
    max_len = max(item[0].size(0) for item in batch)
    mels, durs, altos, tenors, basses = [], [], [], [], []
    for mel, dur, a, t, b in batch:
        pad_amt = max_len - mel.size(0)
        mels.append(  F.pad(mel,  (0,pad_amt), value=0) )
        durs.append(  F.pad(dur,  (0,pad_amt), value=0) )
        altos.append( F.pad(a,    (0,pad_amt), value=0) )
        tenors.append(F.pad(t,    (0,pad_amt), value=0) )
        basses.append(F.pad(b,    (0,pad_amt), value=0) )
    return (
        torch.stack(mels,   0),
        torch.stack(durs,   0),
        torch.stack(altos,  0),
        torch.stack(tenors, 0),
        torch.stack(basses, 0),
    )

class LSTMHarmonizer(nn.Module):
    """
    基于 LSTM 的和声生成模型，输入 pitch embedding + duration embedding。
    输出 Alto, Tenor, Bass 三个声部的 logits。
    """
    def __init__(self,
                 vocab_size=VOCAB_SIZE,
                 emb_dim=EMBED_DIM,
                 hidden_dim=LSTM_HIDDEN,
                 dur_vocab=DUR_VOCAB):
        super().__init__()
        self.pitch_emb = nn.Embedding(vocab_size, emb_dim, padding_idx=0)
        self.dur_emb   = nn.Embedding(dur_vocab, emb_dim, padding_idx=0)
        self.lstm      = nn.LSTM(emb_dim, hidden_dim, batch_first=True)
        self.heads     = nn.ModuleList([
            nn.Linear(hidden_dim, vocab_size) for _ in range(NUM_VOICES)
        ])

    def forward(self, mel_seq, dur_seq):
        pe = self.pitch_emb(mel_seq)
        de = self.dur_emb(torch.clamp(dur_seq, 0, self.dur_emb.num_embeddings-1))
        out, _ = self.lstm(pe + de)
        return [head(out) for head in self.heads]

def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # ↓↓ 重点：定位到项目根的 data/ 目录，而非 harmonizer/data/ ↓↓
    script_dir  = os.path.dirname(os.path.abspath(__file__))   # .../Auto_Harmonizer/harmonizer
    project_root= os.path.abspath(os.path.join(script_dir, os.pardir))  # .../Auto_Harmonizer
    data_dir    = os.path.join(project_root, 'data')           # .../Auto_Harmonizer/data

    print(f"Looking for .npz files in {data_dir}")

    train_files, valid_files, _ = find_npz_splits(data_dir)
    if not train_files or not valid_files:
        raise RuntimeError(f"No train/valid .npz found in {data_dir}")

    print("→ Train files:", train_files)
    print("→ Valid files:", valid_files)

    train_ds = ConcatDataset([HarmonyDataset(p) for p in train_files])
    valid_ds = ConcatDataset([HarmonyDataset(p) for p in valid_files])

    train_ld = DataLoader(train_ds, batch_size=BATCH_SIZE,
                          shuffle=True, collate_fn=pad_collate)
    valid_ld = DataLoader(valid_ds, batch_size=BATCH_SIZE,
                          shuffle=False, collate_fn=pad_collate)

    model     = LSTMHarmonizer().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    criterion = nn.CrossEntropyLoss(ignore_index=0)

    best_val = float('inf')
    for epoch in range(1, EPOCHS+1):
        # 训练
        model.train()
        train_loss = 0.0
        for mel, dur, alto, tenor, bass in tqdm(train_ld, desc=f"[{epoch}/{EPOCHS}] Train"):
            mel, dur, alto, tenor, bass = [t.to(device) for t in (mel, dur, alto, tenor, bass)]
            outs = model(mel, dur)
            loss = sum(
                criterion(o.view(-1, VOCAB_SIZE), tgt.view(-1))
                for o, tgt in zip(outs, (alto, tenor, bass))
            )
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        avg_train = train_loss / len(train_ld)

        # 验证
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for mel, dur, alto, tenor, bass in tqdm(valid_ld, desc=f"[{epoch}/{EPOCHS}] Valid"):
                mel, dur, alto, tenor, bass = [t.to(device) for t in (mel, dur, alto, tenor, bass)]
                outs = model(mel, dur)
                val_loss += sum(
                    criterion(o.view(-1, VOCAB_SIZE), tgt.view(-1))
                    for o, tgt in zip(outs, (alto, tenor, bass))
                ).item()
        avg_val = val_loss / len(valid_ld)

        print(f"→ Epoch {epoch} Summary: train_loss={avg_train:.4f}, valid_loss={avg_val:.4f}")

        # 保存最佳模型
        if avg_val < best_val:
            best_val = avg_val
            torch.save(model.state_dict(), "lstm_harmonizer_with_dur.pth")
            print("  🎉 Saved best model: lstm_harmonizer_with_dur.pth")

    print("✔ Training complete.")

if __name__ == "__main__":
    main()
