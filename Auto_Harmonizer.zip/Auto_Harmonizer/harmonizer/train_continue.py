#!/usr/bin/env python3
# harmonizer/train_continue.py

import os
import glob
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, ConcatDataset
import numpy as np
from tqdm import tqdm

# Hyperparameters
EMBED_DIM   = 128
LSTM_HIDDEN = 256
NUM_VOICES  = 3
VOCAB_SIZE  = 128
BATCH_SIZE  = 16
EPOCHS      = 10   # number of fine-tuning epochs
LR          = 1e-4 # lower learning rate for fine-tuning

# 1) Dataset that loads one .npz file
class HarmonyDataset(Dataset):
    def __init__(self, npz_path):
        data = np.load(npz_path)
        self.melody = torch.from_numpy(data['melody']).long()
        self.alto   = torch.from_numpy(data['alto']).long()
        self.tenor  = torch.from_numpy(data['tenor']).long()
        self.bass   = torch.from_numpy(data['bass']).long()

    def __len__(self):
        return len(self.melody)

    def __getitem__(self, idx):
        return (
            self.melody[idx],
            self.alto[idx],
            self.tenor[idx],
            self.bass[idx]
        )

# 2) Collate fn to pad within each batch
def pad_collate(batch):
    # batch: list of (melody, alto, tenor, bass) tensors, each [T_i]
    max_len = max(item[0].size(0) for item in batch)
    mels, altos, tenors, basses = [], [], [], []
    for melody, alto, tenor, bass in batch:
        L = melody.size(0)
        pad_amt = max_len - L
        mels.append(   F.pad(melody, (0, pad_amt), value=0) )
        altos.append(  F.pad(alto,    (0, pad_amt), value=0) )
        tenors.append( F.pad(tenor,   (0, pad_amt), value=0) )
        basses.append( F.pad(bass,    (0, pad_amt), value=0) )
    return (
        torch.stack(mels,   0),
        torch.stack(altos,  0),
        torch.stack(tenors, 0),
        torch.stack(basses, 0),
    )

# 3) LSTM Harmonizer model
class LSTMHarmonizer(nn.Module):
    def __init__(self,
                 vocab_size=VOCAB_SIZE,
                 emb_dim=EMBED_DIM,
                 hidden_dim=LSTM_HIDDEN):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, emb_dim, padding_idx=0)
        self.lstm      = nn.LSTM(emb_dim, hidden_dim, batch_first=True)
        self.heads     = nn.ModuleList([
            nn.Linear(hidden_dim, vocab_size)
            for _ in range(NUM_VOICES)
        ])

    def forward(self, melody_seq):
        # melody_seq: (batch, seq_len)
        x, _ = self.embedding(melody_seq), None
        out, _ = self.lstm(x)  # (batch, seq_len, hidden_dim)
        return [head(out) for head in self.heads]

# 4) Auto-split data_dir/*.npz into train/valid/test
def find_npz_splits(data_dir):
    npz_files = glob.glob(os.path.join(data_dir, '*.npz'))
    train_files = [p for p in npz_files
                   if 'valid' not in p.lower() and 'test' not in p.lower()]
    valid_files = [p for p in npz_files if 'valid' in p.lower()]
    test_files  = [p for p in npz_files if 'test'  in p.lower()]
    return train_files, valid_files, test_files

def main():
    # device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # locate data/*.npz
    data_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'data')
    )
    train_files, valid_files, _ = find_npz_splits(data_dir)

    if not train_files:
        raise RuntimeError(f"No training .npz files found in {data_dir}")
    if not valid_files:
        raise RuntimeError(f"No validation .npz files found in {data_dir}")

    print("→ Training on:", train_files)
    print("→ Validating on:", valid_files)

    # build datasets
    train_ds = ConcatDataset([HarmonyDataset(p) for p in train_files])
    valid_ds = ConcatDataset([HarmonyDataset(p) for p in valid_files])

    # data loaders with pad_collate
    train_loader = DataLoader(
        train_ds,
        batch_size=BATCH_SIZE,
        shuffle=True,
        collate_fn=pad_collate
    )
    valid_loader = DataLoader(
        valid_ds,
        batch_size=BATCH_SIZE,
        shuffle=False,
        collate_fn=pad_collate
    )

    # model, optimizer, criterion
    model     = LSTMHarmonizer().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    criterion = nn.CrossEntropyLoss(ignore_index=0)

    best_val = float('inf')

    # 5) Training loop
    for epoch in range(1, EPOCHS+1):
        # — train —
        model.train()
        train_loss = 0.0
        train_bar = tqdm(train_loader,
                         desc=f"[Epoch {epoch}/{EPOCHS}] Train",
                         unit="batch")
        for melody, alto, tenor, bass in train_bar:
            melody, alto, tenor, bass = [
                t.to(device) for t in (melody, alto, tenor, bass)
            ]
            outputs = model(melody)
            loss = sum(
                criterion(o.view(-1, VOCAB_SIZE), tgt.view(-1))
                for o, tgt in zip(outputs, (alto, tenor, bass))
            )
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            train_loss += loss.item()
            train_bar.set_postfix(loss=loss.item())

        avg_train = train_loss / len(train_loader)

        # — validate —
        model.eval()
        val_loss = 0.0
        valid_bar = tqdm(valid_loader,
                         desc=f"[Epoch {epoch}/{EPOCHS}] Valid",
                         unit="batch")
        with torch.no_grad():
            for melody, alto, tenor, bass in valid_bar:
                melody, alto, tenor, bass = [
                    t.to(device) for t in (melody, alto, tenor, bass)
                ]
                outputs = model(melody)
                batch_loss = sum(
                    criterion(o.view(-1, VOCAB_SIZE), tgt.view(-1))
                    for o, tgt in zip(outputs, (alto, tenor, bass))
                ).item()
                val_loss += batch_loss
                valid_bar.set_postfix(loss=batch_loss)

        avg_val = val_loss / len(valid_loader)

        print(f"→ Epoch {epoch} Summary: "
              f"train_loss={avg_train:.4f}, valid_loss={avg_val:.4f}")

        # save best checkpoint
        if avg_val < best_val:
            best_val = avg_val
            torch.save(model.state_dict(),
                       "lstm_harmonizer_finetuned.pth")
            print("  🎉 Saved new best: "
                  "lstm_harmonizer_finetuned.pth")

    print("✓ Fine-tuning complete.")

if __name__ == "__main__":
    main()
