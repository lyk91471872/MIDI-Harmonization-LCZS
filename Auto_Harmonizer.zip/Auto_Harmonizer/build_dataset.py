#!/usr/bin/env python3
# build_dataset.py

import json
import numpy as np
import os

def load_jsb(json_path):
    """从 JSON 中抽出 chorales 列表"""
    with open(json_path, 'r') as f:
        data = json.load(f)
    # 顶层可能是 dict 包含一个 list，或直接是 list
    if isinstance(data, dict):
        for v in data.values():
            if isinstance(v, list):
                return v
    elif isinstance(data, list):
        return data
    raise ValueError(f"Unrecognized JSON structure in {json_path}")

def split_voices(chorale):
    """
    chorale: list of chords, 每个 chord 是若干 MIDI pitch 的 list
    返回 melody, alto, tenor, bass 四个 list
    """
    melody, alto, tenor, bass = [], [], [], []
    for chord in chorale:
        # 不足 4 个音补 0
        chord = chord + [0] * (4 - len(chord))
        melody.append(chord[0])
        alto.append(chord[1])
        tenor.append(chord[2])
        bass.append(chord[3])
    return melody, alto, tenor, bass

def infer_durations(melody):
    """
    对 melody list 做 run‐length encoding，输出每个格点的持续长度（以格点数计）
    """
    T = len(melody)
    durations = []
    i = 0
    while i < T:
        p = melody[i]
        if p == 0:
            # rest 当作长度 1
            durations.append(1)
            i += 1
        else:
            # 找到 p 连续出现到哪里
            j = i + 1
            while j < T and melody[j] == p:
                j += 1
            run = j - i
            # 把这段 run 长度都填成 run
            durations.extend([run] * run)
            i = j
    # 如果因为末尾多填了，截断
    durations = durations[:T]
    # 如果少了，用 1 补齐
    durations += [1] * (T - len(durations))
    return durations

def build_dataset(json_paths, output_path='jsbach_dataset.npz'):
    all_m, all_dur, all_a, all_t, all_b = [], [], [], [], []
    for path in json_paths:
        chorales = load_jsb(path)
        for chorale in chorales:
            m, a, t, b = split_voices(chorale)
            d = infer_durations(m)
            all_m.append(m)
            all_dur.append(d)
            all_a.append(a)
            all_t.append(t)
            all_b.append(b)

    # 找到最大长度
    max_len = max(len(x) for x in all_m)

    def pad(seqs):
        return np.array([
            np.pad(x, (0, max_len - len(x)), 'constant', constant_values=0)
            for x in seqs
        ], dtype=np.int64)

    melody_arr    = pad(all_m)
    dur_arr       = pad(all_dur)
    alto_arr      = pad(all_a)
    tenor_arr     = pad(all_t)
    bass_arr      = pad(all_b)

    np.savez(output_path,
             melody=melody_arr,
             melody_dur=dur_arr,
             alto=alto_arr,
             tenor=tenor_arr,
             bass=bass_arr)
    print(f"Saved {output_path}:",
          melody_arr.shape, dur_arr.shape,
          alto_arr.shape, tenor_arr.shape, bass_arr.shape)

if __name__ == "__main__":
    # 你 JSB JSON 文件路径
    jsb_paths = ['data/jsb-chorales-quarter.json']
    build_dataset(jsb_paths, output_path='data/jsbach_with_dur.npz')
