#!/usr/bin/env python3
# inference.py

import os
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import pretty_midi

# Hyperparameters (must match training)
EMBED_DIM   = 128
LSTM_HIDDEN = 256
NUM_VOICES  = 3
VOCAB_SIZE  = 128
MAX_DUR     = 128   # duration‐vocab size used when training
TIME_STEP   = 0.25  # quantization step used when training

# Voice ranges for post‐processing
VOICE_RANGES = {
    "Alto":  (60, 80),
    "Tenor": (50, 72),
    "Bass":  (28, 60),
}

# 1) Model: pitch + duration embedding → LSTM → 3 heads
class LSTMHarmonizer(nn.Module):
    def __init__(self,
                 vocab_size=VOCAB_SIZE,
                 emb_dim=EMBED_DIM,
                 hidden_dim=LSTM_HIDDEN,
                 dur_vocab=MAX_DUR):
        super().__init__()
        self.pitch_emb = nn.Embedding(vocab_size, emb_dim, padding_idx=0)
        self.dur_emb   = nn.Embedding(dur_vocab, emb_dim, padding_idx=0)
        self.lstm      = nn.LSTM(emb_dim, hidden_dim, batch_first=True)
        self.heads     = nn.ModuleList([
            nn.Linear(hidden_dim, vocab_size)
            for _ in range(NUM_VOICES)
        ])

    def forward(self, pitch_seq, dur_seq):
        pe = self.pitch_emb(pitch_seq)
        de = self.dur_emb(torch.clamp(dur_seq, 0, self.dur_emb.num_embeddings-1))
        x, _ = self.lstm(pe + de)
        return [h(x) for h in self.heads]

# 2) Extract melody events from input MIDI
def extract_melody_events(midi_path):
    pm = pretty_midi.PrettyMIDI(midi_path)
    inst = pm.instruments[0]
    notes = sorted(inst.notes, key=lambda n: n.start)
    return [(n.start, n.end, n.pitch) for n in notes]

# 3) Convert events → grid + inferred durations
def events_to_grid_and_dur(events, time_step=TIME_STEP):
    if not events:
        return np.zeros((1,0), int), np.zeros((1,0), int)
    T = int(np.ceil(events[-1][0] / time_step)) + 1
    pitch = np.zeros((1, T), dtype=int)
    for s, _, p in events:
        idx = int(s / time_step)
        pitch[0, idx] = p
    dur = np.zeros_like(pitch[0])
    i = 0
    while i < T:
        p = pitch[0, i]
        if p == 0:
            dur[i] = 1
            i += 1
        else:
            j = i + 1
            while j < T and pitch[0, j] == p:
                j += 1
            run = j - i
            dur[i] = run
            i = j
    return pitch, dur.reshape(1, -1)

# 4) Generate best + second‐best predictions
def generate_harmony(pitch_grid, dur_grid, ckpt_path):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = LSTMHarmonizer().to(device)
    model.load_state_dict(torch.load(ckpt_path, map_location=device))
    model.eval()

    pg = torch.from_numpy(pitch_grid).long().to(device)
    dg = torch.from_numpy(dur_grid).long().to(device)
    with torch.no_grad():
        outs = model(pg, dg)  # list of 3 (1, T, V)
    best, second = {}, {}
    for name, logits in zip(("Alto","Tenor","Bass"), outs):
        top2 = torch.topk(logits[0], 2, dim=-1).indices.cpu().numpy()  # (T,2)
        best[name]   = top2[:,0].tolist()
        second[name] = top2[:,1].tolist()
    return best, second

# 5) Fix parallel fifths (melody ↔ voice)
def interval(a, b):
    return abs((a - b) % 12)

def fix_parallel_fifths(events, best, second):
    out = {n: best[n].copy() for n in best}
    for i in range(1, len(events)):
        mel_prev, mel_curr = events[i-1][2], events[i][2]
        for name in ("Alto","Tenor","Bass"):
            v_prev = best[name][i-1]
            v_curr = out[name][i]
            if interval(mel_prev, v_prev) == 7 and interval(mel_curr, v_curr) == 7:
                out[name][i] = second[name][i]
    return out

# 6) Clamp predictions to voice ranges
def clamp_voice(seq, vmin, vmax):
    return [max(vmin, min(vmax, p)) for p in seq]

# 7) Smooth large jumps
def smooth_voice(name, seq, second_seq, max_jump=7):
    smoothed = []
    for i, p in enumerate(seq):
        if i == 0:
            smoothed.append(p)
            continue
        prev = smoothed[-1]
        jump = p - prev
        if abs(jump) > max_jump:
            alt = second_seq[i]
            if abs(alt - prev) <= max_jump:
                smoothed.append(alt)
            else:
                p_new = prev + max_jump if jump > 0 else prev - max_jump
                smoothed.append(p_new)
        else:
            smoothed.append(p)
    return smoothed

# 8) Write four-part MIDI using original event timings
def write_four_part_midi(events, parts, out_path):
    pm = pretty_midi.PrettyMIDI()
    names = ["Melody","Alto","Tenor","Bass"]
    programs = [0, 52, 56, 32]
    for name, prog in zip(names, programs):
        instr = pretty_midi.Instrument(program=prog, name=name)
        if name == "Melody":
            for s,e,p in events:
                instr.notes.append(pretty_midi.Note(100, int(p), s, e))
        else:
            seq = parts[name]
            for (s,e,_), p in zip(events, seq):
                if p > 0:
                    instr.notes.append(pretty_midi.Note(100, p, s, e))
        pm.instruments.append(instr)
    pm.write(out_path)
    print(f"Saved: {out_path}")

# 9) Main entry point
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input_midi",  help="input monophonic MIDI")
    parser.add_argument("output_midi", help="output four-part MIDI")
    parser.add_argument("--ckpt", default="lstm_harmonizer_with_dur.pth",
                        help="trained checkpoint path")
    args = parser.parse_args()

    events = extract_melody_events(args.input_midi)
    if not events:
        raise RuntimeError("No melody notes found in input MIDI.")

    pitch_grid, dur_grid = events_to_grid_and_dur(events)
    best, second = generate_harmony(pitch_grid, dur_grid, args.ckpt)

    # post‐processing
    for name in ("Alto","Tenor","Bass"):
        best[name] = clamp_voice(best[name], *VOICE_RANGES[name])

    best = fix_parallel_fifths(events, best, second)

    for name in ("Alto","Tenor","Bass"):
        best[name] = smooth_voice(name, best[name], second[name], max_jump=7)

    write_four_part_midi(events, best, args.output_midi)
