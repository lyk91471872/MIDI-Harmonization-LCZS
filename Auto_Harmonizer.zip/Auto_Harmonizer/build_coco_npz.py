# build_coco_npz.py
import os
import numpy as np
import pretty_midi

def quantize_midi(pm, time_step=0.25):
    end_times = [instr.get_end_time() for instr in pm.instruments]
    total = max(end_times) if end_times else 0
    T = max(1, int(np.ceil(total / time_step)))
    voices = []
    for instr in pm.instruments[:4]:
        arr = np.zeros(T, dtype=np.int64)
        for note in instr.notes:
            idx = int(note.start / time_step)
            if idx < T:
                arr[idx] = note.pitch
        voices.append(arr)
    # 如果不足 4 轨，补零
    while len(voices) < 4:
        voices.append(np.zeros(T, dtype=np.int64))
    return voices

def build_npz_from_folder(folder_path, output_path):
    melody_list=[]; alto_list=[]; tenor_list=[]; bass_list=[]
    print(f"\n→ 在 {folder_path} 下寻找 MIDI ...")
    for root, _, files in os.walk(folder_path):
        for fn in files:
            if fn.lower().endswith(('.mid','.midi')):
                full = os.path.join(root, fn)
                try:
                    pm = pretty_midi.PrettyMIDI(full)
                    s,a,t,b = quantize_midi(pm)
                    melody_list.append(s); alto_list.append(a)
                    tenor_list.append(t); bass_list.append(b)
                except Exception as e:
                    print(f"  × 处理 {fn} 失败：{e}")
    if not melody_list:
        print(f"  × 没有找到任何 MIDI 文件，跳过 {folder_path}")
        return

    # padding
    L = max(len(x) for x in melody_list)
    def pad(xs):
        return np.stack([np.pad(x,(0,L-len(x)),'constant') for x in xs],axis=0)
    np.savez(output_path,
             melody=pad(melody_list),
             alto=pad(alto_list),
             tenor=pad(tenor_list),
             bass=pad(bass_list))
    print(f"√ 已保存 {output_path}，shape = {pad(melody_list).shape}")

if __name__=="__main__":
    # 确保在 cocochorales_tiny_v1_midi 目录下执行
    for split in ("train","valid","test"):
        build_npz_from_folder(split, f"{split}_coco_tiny.npz")
